import SwiftUI
import DredgeCore
@main struct DredgeApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}
