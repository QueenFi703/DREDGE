DREDGE – Final Integrated Project

Open in Xcode, fix signing, run.
